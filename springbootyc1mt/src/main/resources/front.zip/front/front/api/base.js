﻿const base = {
    url : "http://localhost:8080/springbootyc1mt/"
}
export default base
